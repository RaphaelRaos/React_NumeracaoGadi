import React from 'react'

export const HeaderLogin = () => {

    return (        
        <div>
            <div className="App">
                <div className="App-headerLogin"> 
                                                  
                    <h3>SISTEMA DE NUMERAÇÃO</h3>                    
                    
                </div>      
            </div>
        </div>
    )
}