import React from 'react';
import { Body, Container } from './styles'
import { Header } from '../header/header';

export const Home = () => {

    return (
        <div>
            <Header />
            <Body>
                <Container>

                </Container>
            </Body>
        </div>

    )
}